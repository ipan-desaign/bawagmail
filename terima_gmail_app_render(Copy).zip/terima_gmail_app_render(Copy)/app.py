import os
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'terima_gmail_secret_key_change_me'
DB_NAME = 'database.db'

# Link media langsung hardcode di dalam script
VIDEO_BANNER_URL = 'https://files.catbox.moe/r21eis.jpg'
BG_SOUND_URL = ''  # Masukkan URL audio MP3 langsung di sini jika ada

ADMIN_USERNAME = 'NINOOONIHBOS'
ADMIN_PASSWORD = 'aripgantengbanget'

def init_db():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            dana_number TEXT NOT NULL,
            is_admin INTEGER DEFAULT 0
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS rooms (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            tariff TEXT NOT NULL,
            room_password TEXT NOT NULL,
            est_date TEXT NOT NULL,
            status TEXT DEFAULT 'BUKA'
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS submissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            dana_number TEXT NOT NULL,
            room_name TEXT NOT NULL,
            email TEXT NOT NULL,
            status TEXT DEFAULT 'PENDING',
            created_at TEXT NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS approved_emails (
            email TEXT PRIMARY KEY,
            approved_at TEXT NOT NULL
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS admin_email_stock (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL DEFAULT 'sgsg1122',
            birth_year TEXT NOT NULL DEFAULT '2000 - 2006',
            is_used INTEGER DEFAULT 0
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
    ''')
    
    # Check column upgrades
    cursor.execute("PRAGMA table_info(admin_email_stock)")
    columns = [col[1] for col in cursor.fetchall()]
    if 'password' not in columns:
        cursor.execute("ALTER TABLE admin_email_stock ADD COLUMN password TEXT NOT NULL DEFAULT 'sgsg1122'")
    if 'birth_year' not in columns:
        cursor.execute("ALTER TABLE admin_email_stock ADD COLUMN birth_year TEXT NOT NULL DEFAULT '2000 - 2006'")

    # Hapus akun admin lama 'admin' jika ada, lalu buat/update admin baru
    cursor.execute("DELETE FROM users WHERE username = 'admin'")
    
    cursor.execute("SELECT * FROM users WHERE username = ?", (ADMIN_USERNAME,))
    if not cursor.fetchone():
        cursor.execute("INSERT INTO users (username, password, dana_number, is_admin) VALUES (?, ?, ?, ?)",
                       (ADMIN_USERNAME, ADMIN_PASSWORD, '081234567890', 1))
    else:
        cursor.execute("UPDATE users SET password = ?, is_admin = 1 WHERE username = ?",
                       (ADMIN_PASSWORD, ADMIN_USERNAME))
        
    defaults = {
        'tutorial_link': 'https://youtube.com'
    }
    for k, v in defaults.items():
        cursor.execute("SELECT * FROM settings WHERE key = ?", (k,))
        if not cursor.fetchone():
            cursor.execute("INSERT INTO settings (key, value) VALUES (?, ?)", (k, v))
        
    conn.commit()
    conn.close()

init_db()

@app.route('/')
def index():
    if 'username' in session:
        if session.get('is_admin'):
            return redirect(url_for('admin_dashboard'))
        return redirect(url_for('customer_dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        action = request.form.get('action')
        username = request.form.get('username').strip()
        password = request.form.get('password').strip()
        
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        
        if action == 'register':
            dana_number = request.form.get('dana_number', '').strip()
            if not username or not password or not dana_number:
                flash('Semua field wajib diisi!', 'danger')
                conn.close()
                return redirect(url_for('login'))
            try:
                cursor.execute("INSERT INTO users (username, password, dana_number, is_admin) VALUES (?, ?, ?, 0)",
                               (username, password, dana_number))
                conn.commit()
                flash('Registrasi berhasil! Silakan login.', 'success')
            except sqlite3.IntegrityError:
                flash('Username sudah terdaftar!', 'danger')
        else:
            cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password))
            user = cursor.fetchone()
            if user:
                session['username'] = user[1]
                session['dana_number'] = user[3]
                session['is_admin'] = user[4]
                conn.close()
                if user[4] == 1:
                    return redirect(url_for('admin_dashboard'))
                else:
                    return redirect(url_for('customer_dashboard'))
            else:
                flash('Username atau password salah!', 'danger')
        conn.close()
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/customer')
def customer_dashboard():
    if 'username' not in session or session.get('is_admin'):
        return redirect(url_for('login'))
    
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    settings = {'video_banner': VIDEO_BANNER_URL, 'bg_sound': BG_SOUND_URL}
    cursor.execute("SELECT key, value FROM settings")
    for row in cursor.fetchall():
        settings[row[0]] = row[1]
    
    cursor.execute("SELECT * FROM rooms WHERE status = 'BUKA'")
    rooms = cursor.fetchall()
    
    cursor.execute("SELECT room_name, email, status, created_at FROM submissions WHERE username = ? ORDER BY id DESC LIMIT 20", (session['username'],))
    history = cursor.fetchall()
    
    conn.close()
    return render_template('customer.html', username=session['username'], dana_number=session['dana_number'], rooms=rooms, history=history, settings=settings)

@app.route('/generate_emails', methods=['POST'])
def generate_emails():
    if 'username' not in session or session.get('is_admin'):
        return jsonify({"emails": [], "error": "Unauthorized"}), 401
    
    try:
        count = int(request.form.get('count', 1))
    except:
        count = 1
        
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    cursor.execute("SELECT email, password, birth_year FROM admin_email_stock WHERE is_used = 0")
    available_stock = cursor.fetchall()
    
    selected_emails = []
    for row in available_stock:
        em, pwd, yr = row[0], row[1], row[2]
        cursor.execute("SELECT 1 FROM approved_emails WHERE email = ?", (em,))
        if not cursor.fetchone():
            selected_emails.append({"email": em, "password": pwd, "birth_year": yr})
            if len(selected_emails) >= count:
                break
                
    for item in selected_emails:
        cursor.execute("UPDATE admin_email_stock SET is_used = 1 WHERE email = ?", (item['email'],))
        
    conn.commit()
    conn.close()
    
    return jsonify({"emails": selected_emails})

@app.route('/submit_emails', methods=['POST'])
def submit_emails():
    if 'username' not in session or session.get('is_admin'):
        return redirect(url_for('login'))
    
    room_name = request.form.get('room_name')
    raw_emails = request.form.get('emails', '')
    
    email_list = [e.strip() for e in raw_emails.splitlines() if e.strip()]
    if not email_list:
        flash('Tidak ada email yang dimasukkan!', 'danger')
        return redirect(url_for('customer_dashboard'))
    
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    inserted_count = 0
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    for em in email_list:
        cursor.execute("SELECT 1 FROM approved_emails WHERE email = ?", (em,))
        if not cursor.fetchone():
            cursor.execute("INSERT INTO submissions (username, dana_number, room_name, email, created_at) VALUES (?, ?, ?, ?, ?)",
                           (session['username'], session['dana_number'], room_name, em, now_str))
            inserted_count += 1
            
    conn.commit()
    conn.close()
    
    if inserted_count > 0:
        flash(f'Berhasil mengirim {inserted_count} email ke room {room_name}!', 'success')
    else:
        flash('Semua email yang Anda masukkan sudah pernah disetujui sebelumnya!', 'danger')
        
    return redirect(url_for('customer_dashboard'))

@app.route('/admin')
def admin_dashboard():
    if 'username' not in session or not session.get('is_admin'):
        return redirect(url_for('login'))
        
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM rooms")
    rooms = cursor.fetchall()
    
    cursor.execute("SELECT id, username, dana_number, room_name, email, status, created_at FROM submissions ORDER BY id DESC")
    submissions = cursor.fetchall()
    
    settings = {'video_banner': VIDEO_BANNER_URL, 'bg_sound': BG_SOUND_URL}
    cursor.execute("SELECT key, value FROM settings")
    for row in cursor.fetchall():
        settings[row[0]] = row[1]
        
    cursor.execute("SELECT id, email, password, birth_year, is_used FROM admin_email_stock ORDER BY id DESC")
    email_stocks = cursor.fetchall()
    
    conn.close()
    return render_template('admin.html', rooms=rooms, submissions=submissions, settings=settings, email_stocks=email_stocks)

@app.route('/admin/room/add', methods=['POST'])
def add_room():
    if 'username' not in session or not session.get('is_admin'):
        return redirect(url_for('login'))
        
    name = request.form.get('name')
    tariff = request.form.get('tariff')
    room_password = request.form.get('room_password')
    est_date = request.form.get('est_date')
    
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO rooms (name, tariff, room_password, est_date, status) VALUES (?, ?, ?, ?, 'BUKA')",
                   (name, tariff, room_password, est_date))
    conn.commit()
    conn.close()
    flash('Room berhasil ditambahkan!', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/room/toggle/<int:room_id>')
def toggle_room(room_id):
    if 'username' not in session or not session.get('is_admin'):
        return redirect(url_for('login'))
        
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT status FROM rooms WHERE id = ?", (room_id,))
    res = cursor.fetchone()
    if res:
        new_status = 'TUTUP' if res[0] == 'BUKA' else 'BUKA'
        cursor.execute("UPDATE rooms SET status = ? WHERE id = ?", (new_status, room_id))
        conn.commit()
    conn.close()
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/submission/<int:sub_id>/<action>')
def handle_submission(sub_id, action):
    if 'username' not in session or not session.get('is_admin'):
        return redirect(url_for('login'))
        
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    if action == 'approve':
        cursor.execute("UPDATE submissions SET status = 'DISETUJUI' WHERE id = ?", (sub_id,))
        cursor.execute("SELECT email FROM submissions WHERE id = ?", (sub_id,))
        sub = cursor.fetchone()
        if sub and sub[0]:
            try:
                cursor.execute("INSERT OR IGNORE INTO approved_emails (email, approved_at) VALUES (?, ?)",
                               (sub[0].strip(), datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            except:
                pass
        conn.commit()
        flash('Setoran disetujui!', 'success')
    elif action == 'reject':
        cursor.execute("UPDATE submissions SET status = 'DITOLAK' WHERE id = ?", (sub_id,))
        conn.commit()
        flash('Setoran ditolak.', 'warning')
        
    conn.close()
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/settings', methods=['POST'])
def update_settings():
    if 'username' not in session or not session.get('is_admin'):
        return redirect(url_for('login'))
        
    tutorial_link = request.form.get('tutorial_link')
    
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('tutorial_link', ?)", (tutorial_link,))
    conn.commit()
    conn.close()
    
    flash('Pengaturan berhasil diperbarui!', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/emails/add', methods=['POST'])
def add_admin_emails():
    if 'username' not in session or not session.get('is_admin'):
        return redirect(url_for('login'))
        
    raw_emails = request.form.get('emails', '')
    password = request.form.get('password', 'sgsg1122').strip()
    birth_year = request.form.get('birth_year', '2000 - 2006').strip()
    
    email_list = [e.strip() for e in raw_emails.splitlines() if e.strip()]
    
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    added_count = 0
    for em in email_list:
        try:
            cursor.execute("INSERT INTO admin_email_stock (email, password, birth_year, is_used) VALUES (?, ?, ?, 0)",
                           (em, password, birth_year))
            added_count += 1
        except:
            pass
    conn.commit()
    conn.close()
    
    flash(f'Berhasil menambahkan {added_count} stok email baru ke sistem!', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/emails/delete/<int:email_id>')
def delete_admin_email(email_id):
    if 'username' not in session or not session.get('is_admin'):
        return redirect(url_for('login'))
        
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM admin_email_stock WHERE id = ?", (email_id,))
    conn.commit()
    conn.close()
    flash('Stok email berhasil dihapus.', 'success')
    return redirect(url_for('admin_dashboard'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
